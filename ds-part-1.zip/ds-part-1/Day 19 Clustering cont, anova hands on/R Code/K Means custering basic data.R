install.packages("plyr")
library(plyr)


a <- list(0,0,1,1,5,5,6,6)

a

b <-  list(0,1,0,1,5,6,5,6) #  

b

data <- cbind(a,b) # column bind

data

plot(data)

km01 <- kmeans(data,2) #kmeans clustering
str(km01)

# a little more detailed basic data

c <- list(0,0,1,1,0,0,1,1,5,5,6,6,5,5,6,6)

c

d <-  list(0,1,0,1,5,6,5,6,0,1,0,1,5,6,5,6) #  

d

data01 <- cbind(c,d) # column bind

write.csv(data01, "test.csv")

data01

plot(data01, type="n")
text(data01, rownames(data01))
km02 <- kmeans(data01,14) #kmeans clustering
str(km02)
