read.csv(file="", header = TRUE, sep=",")

install.packages("foreign")
library(foreign)   # used to load statistical software packages

indata <- read.spss("cancer.sav")
indataframe <- as.data.frame(indata)
str(indataframe)
summary(indataframe)


install.packages("sas7bdat")  # or install Hmisc
library(sas7bdat)
data(sas7bdat.sources)


install.packages("RODBC")
library(RODBC)
odbcDataSources()
getwd()

myconn <-  odbcConnectAccess("(Microsoft Access Driver(*.mdb, *.accdb)); Dbq=A.mdb")
myconn <- odbcDriverConnect("Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=E:/Classes/Basic R/Sample - Coffee Chain.mdb")


Test <- sqlFetch(myconn, "Location")
Test


library(RODBC).    
## set the database path
inCopyDbPath <- "E:/Classes/Basic R/Sample - Coffee Chain.mdb"
## connect to the database
conAccdb <- odbcDriverConnect(inCopyDbPath) 

## Fetch the tables from the database. Modify the as-is and string settings as desired
pots <- sqlFetch(conAccdb,"tbl_Pots",as.is=FALSE, stringsAsFactors = FALSE)
pans <- sqlFetch(conAccdb,"tbl_Pans",as.is=FALSE, stringsAsFactors = FALSE)
## Save the tables
save(pots, file = "C/R_Work/pots.rda")
save(pans, file = "C:/R_Work/pans.rda")
close(conAccdb)









library(base)
web_page_data <- readLines("http://www.edureka.co")

install.packages("RCurl")
library(RCurl)
data2 <- getURL("http://www.edureka.co")
