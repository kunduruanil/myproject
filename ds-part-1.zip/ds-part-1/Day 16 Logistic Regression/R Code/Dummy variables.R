install.packages("psych")
library(psych)
?psych
data("iris")
View(iris)
species_dummy <- dummy.code(iris$Species, group = NULL)
?dummy.code()
iris <- as.data.frame(cbind(iris,species_dummy))
