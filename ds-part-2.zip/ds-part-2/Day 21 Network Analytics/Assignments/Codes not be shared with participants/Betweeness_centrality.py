

import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx 

G = pd.read_csv("D:\\Data Science\\Data Science\\Rcodes\\Network Analytics\\routes.csv")

G = G.iloc[:,1:10]

g = nx.Graph()

g = nx.from_pandas_edgelist(G,source='Source Airport',target='Destination Airport')

print(nx.info(g))

b=nx.betweenness_centrality(g) # Betweeness_Centrality

print(b) 

plt.figure(figsize=(20, 20))

pos=nx.spring_layout(g, k=0.15)

nx.draw_networkx(g,pos,node_size=25, node_color='blue')

plt.show()