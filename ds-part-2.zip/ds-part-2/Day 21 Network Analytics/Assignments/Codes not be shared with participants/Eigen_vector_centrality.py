import pandas as pd 
import networkx as nx 
import matplotlib.pyplot as plt

data = pd.read_csv("D:\\Data Science\\Data Science\\Rcodes\\Network Analytics\\routes.csv")
G = nx.path_graph(4)
G = nx.Graph()
FG = nx.from_pandas_edgelist(data, source='Source Airport', target='Destination Airport', edge_attr=True,)
FG.nodes()
FG.edges()
nx.draw_networkx(FG, with_labels=True)
G = nx.path_graph(4)
centrality = nx.eigenvector_centrality(FG) # Eigen vector centrality

pos=nx.spring_layout(FG, k=0.15)
nx.draw_networkx(FG,pos,node_size=25, node_color='blue')
plt.show()
print(['{} {:0.2f}'.format(node, centrality[node]) for node in centrality])

########################################################################################














