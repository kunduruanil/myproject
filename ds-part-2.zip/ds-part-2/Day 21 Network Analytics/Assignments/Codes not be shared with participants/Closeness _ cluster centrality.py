import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
data = pd.read_csv("D:\\Data Science\\Data Science\\Rcodes\\Network Analytics\\routes.csv")
g = nx.Graph() 

g = nx.from_pandas_edgelist(data,source = "Source Airport",target = "Destination Airport")

print(nx.info(g))

plt.figure(figsize = (20,20))
pos=nx.spring_layout(g, k=0.15)
nx.draw_networkx(g,pos,node_size=25, node_color='Green')
plt.show()
g=nx.erdos_renyi_graph(10,0.4) 

# Average clustering

cc=nx.average_clustering(g) 


# closeness centrality

closeness = nx.closeness_centrality(g)

# cluster coefficient

cluster_coeff = nx.clustering(g)
