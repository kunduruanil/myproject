install.packages("tree")
library(tree)

data()
data("iris")
View(iris)
?iris

##### Using D.Tree #####
#library(tree)
iris_tree <- tree(Species~.,data=iris)

plot(iris_tree)
text(iris_tree,pretty = 0)

pred_tree <- as.data.frame(predict(iris_tree,iris))
pred_tree["final"] <- NULL

for (i in 1:nrow(pred_tree)){
  pred_tree[i,"final"] <- ifelse(pred_tree[i,"setosa"]>0.5,"setosa",ifelse(pred_tree[i,"versicolor"]>0.5,"versicolor","virginica"))
}

library(gmodels)
CrossTable(iris$Species,pred_tree$final)

mean(pred_tree$final==iris$Species) # Accuracy = 0.9733

