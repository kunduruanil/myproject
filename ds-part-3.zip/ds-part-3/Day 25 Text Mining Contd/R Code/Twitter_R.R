install.packages("twitteR")
library("twitteR")
install.packages("ROAuth")
library("ROAuth")
cred <- OAuthFactory$new(consumerKey='YWZ8YD6Z6mgXEotNl0pzfXXDw', # Consumer Key (API Key)
                         consumerSecret='S6XeIeP47nkLnLsOvZqAY60c6O6N3tnn8AvGLdnu9kOrxHtI3m', #Consumer Secret (API Secret)
                         requestURL='https://api.twitter.com/oauth/request_token',
                         accessURL='https://api.twitter.com/oauth/access_token',
                         authURL='https://api.twitter.com/oauth/authorize')

save(cred, file="twitter authentication.Rdata")

load("twitter authentication.Rdata")

install.packages("base64enc")
library(base64enc)

install.packages("httpuv")
library(httpuv)
]
setup_twitter_oauth("YWZ8YD6Z6mgXEotNl0pzfXXDw", # Consumer Key (API Key)
                    "S6XeIeP47nkLnLsOvZqAY60c6O6N3tnn8AvGLdnu9kOrxHtI3m", #Consumer Secret (API Secret)
                    "721595950070796288-qFVZxlxZMSE3vo7kKXYJwSSSasbwMHA",  # Access Token
                    "4MC1Pe0Svr0gJzFSromRJBxrUg0Ay8GiNaSxQMDH4mKKM")  #Access Token Secret



Tweets <- userTimeline('TeamBarackObama', n = 3400,includeRts = T)

TweetsDF <- twListToDF(Tweets)
write.csv(TweetsDF, "Tweetsnew.csv",row.names = FALSE)

getwd()
